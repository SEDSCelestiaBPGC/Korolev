import{a as t}from"../chunks/entry.DEewDx7I.js";export{t as start};
