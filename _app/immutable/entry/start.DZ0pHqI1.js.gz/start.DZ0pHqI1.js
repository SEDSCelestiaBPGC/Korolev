import{a as t}from"../chunks/entry.Ciqc474Y.js";export{t as start};
