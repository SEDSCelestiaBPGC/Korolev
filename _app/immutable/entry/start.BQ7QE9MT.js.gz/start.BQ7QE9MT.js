import{a as t}from"../chunks/entry.BXV_NEKX.js";export{t as start};
