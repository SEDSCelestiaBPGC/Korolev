import{a as t}from"../chunks/entry.BHXfnqVR.js";export{t as start};
