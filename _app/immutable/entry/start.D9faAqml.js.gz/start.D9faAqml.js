import{a as t}from"../chunks/entry.DW3x-RYX.js";export{t as start};
