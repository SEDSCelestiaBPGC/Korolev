import{a as t}from"../chunks/entry.P54mKbLO.js";export{t as start};
