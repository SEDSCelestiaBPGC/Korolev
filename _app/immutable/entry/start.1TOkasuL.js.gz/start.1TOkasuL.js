import{a as t}from"../chunks/entry.DaQlsFjz.js";export{t as start};
