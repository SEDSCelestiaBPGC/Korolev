import{a as t}from"../chunks/entry.DdnFoKce.js";export{t as start};
