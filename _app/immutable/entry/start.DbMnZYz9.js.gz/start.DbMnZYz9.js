import{a as t}from"../chunks/entry.DjtyPcY6.js";export{t as start};
