import{a as t}from"../chunks/entry.BINN8H7K.js";export{t as start};
