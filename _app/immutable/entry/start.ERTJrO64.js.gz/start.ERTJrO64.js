import{a as t}from"../chunks/entry.Cb8PSUUD.js";export{t as start};
