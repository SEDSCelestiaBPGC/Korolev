var s;const a=((s=globalThis.__sveltekit_g5ye1i)==null?void 0:s.base)??"";var e;const t=((e=globalThis.__sveltekit_g5ye1i)==null?void 0:e.assets)??a;export{t as a,a as b};
